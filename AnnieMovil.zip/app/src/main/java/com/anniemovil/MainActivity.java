package com.anniemovil;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.RequestQueue;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    private RequestQueue requestQueue;
    private EditText et_user, et_pass;
    private Button btn_submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String a = "";


        et_user = (EditText) findViewById(R.id.et_user);
        et_pass = (EditText) findViewById(R.id.et_pass);

        btn_submit = (Button) findViewById(R.id.btn_submit);

        btn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String data = "{ \"usr_login\": [{\"id_usr\": \"" + et_user.getText().toString() + "\",\"psw_usr\":\"" + et_pass.getText().toString() + "\"}]}";

                Log.i("VOLLEY", data);
                getData(data);
            }
        });
    }

    public void getData(String data){

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        String urlbase = "https://annie-fe.com/annie_lab/v2/backend/ServiceInterface/";
        String servicio = "SIapp_usr.php/usr_login";

        try {
            URL url = new URL (urlbase + servicio);
            HttpURLConnection con = (HttpURLConnection)url.openConnection();
            con.setRequestProperty("Content-Type", "application/json; utf-8");
            con.setRequestProperty("Accept", "application/json");
            con.setDoOutput(true);

            String jsonInputString = data;

            try(OutputStream os = con.getOutputStream()) {
                byte[] input = jsonInputString.getBytes("utf-8");
                os.write(input, 0, input.length);
            }

            try(BufferedReader br = new BufferedReader(
                    new InputStreamReader(con.getInputStream(), "utf-8"))) {
                StringBuilder response = new StringBuilder();
                String responseLine = null;
                while ((responseLine = br.readLine()) != null) {
                    response.append(responseLine.trim());
                }
                Log.i("Servicio", response.toString());

                try {
                    JSONObject obj_json = new JSONObject(response.toString());
                    JSONArray usr_login = new JSONArray(obj_json.getString("usr_login"));
                    String SAuth = "";
                    String SUser = "";

                    for(int i=0; i < usr_login.length(); i++) {
                        JSONObject objusr_login = usr_login.getJSONObject(i);
                        SAuth = objusr_login.getString("token_auth");
                        SUser = objusr_login.getString("id_usr");
                    }

                    Intent menu = new Intent(this, Menu.class);
                    menu.putExtra("Auth", SAuth);
                    menu.putExtra("User", SUser);
                    startActivity(menu);

                } catch (JSONException e) {
                    Toast.makeText(getApplicationContext(),"Server Error",Toast.LENGTH_LONG).show();
                }


            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}